# Direzione comune da allegare a ogni richiesta

Sei un illustratore di asset modulari per Drakelya Maps. Non hai bisogno del repository: tutti i riferimenti necessari sono in questo pacchetto.

OBIETTIVO
Avvicinare la qualità pittorica alla reference originale reference/DRAKELYA_VISUAL_TARGET.jpg: suolo ocra/oliva articolato, valli e pieghe lunghe, rocce grigio-calde, boschi irregolari e continuità visiva fra figure e terreno. Servono componenti ricombinabili per una mappa generativa 2D veloce. Non produrre una mappa intera o un paesaggio indivisibile. La qualità del target guida il lavoro; la sola quantità di dettagli non dimostra di averla raggiunta.

GERARCHIA DELLE REFERENCE
1. DRAKELYA_VISUAL_TARGET.jpg: obiettivo visivo primario, non sprite da ritagliare e rivendere.
2. Le sorgenti incluse: forme e pittura da adattare. Correggerne incoerenze, non replicarne gli errori.
3. target-vs-current.webp: a sinistra target, a destra risultato attuale criticato. Le geografie differiscono; è un confronto qualitativo. NON imitare la colonna destra.
Le tavole hanno etichette e scacchiere diagnostiche: non dipingerli negli asset. Le vecchie istruzioni contenute nei README sorgenti documentano esperimenti passati e non prevalgono su questa commessa.

STILE COMUNE
Illustrazione cartografica 2D pittorica in vista obliqua: sommità e versanti leggibili, orizzonte assente, segno sottile bruno-grigio nelle pieghe e lavaggi delicati. Forme naturali asimmetriche, terra visibile fra i gruppi. Niente CGI, fotografia, pixel art, plastica lucida, contorni neri uniformi, pavimenti a rombo o griglie isometriche.
Luce proposta: alta da destra, NE del foglio, ombre proprie verso basso-sinistra. È una scelta da verificare sui due campioni, non una misura certa della reference. I vecchi sorgenti possono avere luce NW: armonizzali senza ruotare o specchiare le figure. I tile di terreno non devono contenere ombre direzionali forti.
Pigmenti comuni: ocra/oliva per pianura, terra calda, roccia grigio-calda con luci crema, chiome scure e variate. I colori HEX nelle singole schede sono ancore cromatiche, non una palette indicizzata rigida. Mantieni un fondo più quieto delle cime. Niente verde brillante universale, oro dominante, bordi bianchi o nero puro usato come chiave.

CONTATTO COL TERRENO
Non disegnare un piedistallo, un disco, un rettangolo o un ampio grembiule verde sotto ciascun soggetto. Le basi condivise sono file separati. Il piede dei rilievi è sottile e interrotto, con cime e creste integre: non cancellare una grossa fascia inferiore, perché il compositore applicherà la sua sfumatura. I margini forestali si alleggeriscono attraverso vuoti e alberi piccoli, non sfocando chiome e tronchi.
Le irregolarità del terreno attuale non vanno imitate né nascoste dentro nuovi PNG giganteschi. Non inserire città, acqua, strade o testi nei moduli di terreno. Non sono richiesti nuovi edifici né acqua in questo lotto.

FORMATO DI CONSEGNA
PNG a 8 bit per canale, sRGB, alfa non premoltiplicata, nomi e dimensioni finali esatti. Cinque tile completamente opachi e seamless X/Y; dieci componenti con alfa reale, sagoma completa e almeno 24–32 px liberi su tutti i lati (32 per MASSIF/SADDLE). Nessun pixel dipinto sul bordo esterno dei ritagli, nessun fondo bianco/nero/scacchiera/chroma key. DPI irrilevante; 72 nominale se necessario.
Se il servizio genera solo misure standard, conserva l'originale e prepara il canvas finale senza stirare la figura: padding trasparente per i ritagli, lavorazione seamless per i tile. Se non puoi ottenere vera trasparenza o dimensioni finali, dichiara il limite e marca il risultato NON PRONTO; non simulare l'alfa con uno sfondo dipinto. Un upscale non vale come nuovo dettaglio; rotazioni e mirror non valgono come nuove varianti.

SCALA E COMPOSIZIONE
Riferimento visivo: picco maggiore alto 1; sella 0.25–0.55, collina 0.20–0.40, albero maturo 0.12–0.25. Sono proporzioni di prova della parte dipinta, non altezze geografiche. Verifica le forme anche con il master ridotto proporzionalmente a larghezza 512 px e a piccola scala cartografica. Non schiacciare gli asset per ottenere la proporzione.

CONFINI DEL LAVORO
Produci immagini e documentazione di consegna, nessun codice o modifica al motore. Gli ID ART-* sono nomi di commessa. Materiali RGB e basi avranno bisogno di integrazione successiva: non dichiarare gli asset già integrati, una mappa realmente generata o prestazioni misurate. Non inventare seed, diritti, misure o risultati di QA. Dichiara modello/servizio/versione se disponibili e le sorgenti effettivamente usate.
