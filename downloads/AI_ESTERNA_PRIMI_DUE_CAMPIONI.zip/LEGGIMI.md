# Primo invio all'AI esterna — due campioni

Allega questo ZIP e incolla [00_PRIMO_MESSAGGIO_DA_COPIARE.txt](00_PRIMO_MESSAGGIO_DA_COPIARE.txt). Se la piattaforma non apre archivi, estrai e allega le immagini singolarmente insieme al prompt relativo.

Produci soltanto MASSIF (832×672) e SADDLE (832×338), con alfa reale. I due prompt in prompt/ includono tutte le regole comuni. Il target originale e le quattro sorgenti high/low sono inclusi. Le prove sono definite in [03_CONSEGNA_E_QA.md](03_CONSEGNA_E_QA.md); le sezioni sugli altri13 descrivono il seguito, non un ordine di eseguirlo ora.

Alcuni ID di confronto presenti nelle schede sono controlli secondari contenuti nel pacchetto completo. In questo primo invio usa target e kit v4 allegati come riferimenti sufficienti per i due campioni.

Dopo la presentazione dei due campioni fermati per revisione. Il pacchetto completo servirà soltanto per il seguito. Non è richiesto accesso al progetto né una modifica al codice.
